CREATE DATABASE  IF NOT EXISTS `db_project_se2` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `db_project_se2`;
-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: db_project_se2
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `idemployees` int NOT NULL AUTO_INCREMENT,
  `idemployee` int NOT NULL,
  `idgrocery` int NOT NULL,
  PRIMARY KEY (`idemployees`),
  KEY `f01_employees_idx` (`idemployee`),
  KEY `f02_employees_idx` (`idgrocery`),
  CONSTRAINT `f01_employees` FOREIGN KEY (`idemployee`) REFERENCES `user` (`iduser`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `f02_employees` FOREIGN KEY (`idgrocery`) REFERENCES `grocery` (`idgrocery`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (4,2993,2502);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `favourite_groceries(idcustomer, numreservations)`
--

DROP TABLE IF EXISTS `favourite_groceries(idcustomer, numreservations)`;
/*!50001 DROP VIEW IF EXISTS `favourite_groceries(idcustomer, numreservations)`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `favourite_groceries(idcustomer, numreservations)` AS SELECT 
 1 AS `idcustomer`,
 1 AS `numReservations`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `grocery`
--

DROP TABLE IF EXISTS `grocery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grocery` (
  `idgrocery` int NOT NULL AUTO_INCREMENT,
  `idowner` int NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `name` varchar(45) NOT NULL,
  `maxSpotsInside` int NOT NULL,
  `openingHour` int NOT NULL DEFAULT '8',
  `closingHour` int NOT NULL DEFAULT '20',
  PRIMARY KEY (`idgrocery`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  KEY `f_01_grocery_idx` (`idowner`),
  CONSTRAINT `f_01_grocery` FOREIGN KEY (`idowner`) REFERENCES `user` (`iduser`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2764 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grocery`
--

LOCK TABLES `grocery` WRITE;
/*!40000 ALTER TABLE `grocery` DISABLE KEYS */;
INSERT INTO `grocery` VALUES (2234,2424,9,47,'grocery0',3,8,20),(2235,2424,9,45,'grocery1',2,8,20),(2236,2424,8,45,'grocery2',2,0,24),(2501,2424,45,9,'grocery3',2,0,24),(2502,2424,45.4635,9.2278,'grocery4',2,0,24);
/*!40000 ALTER TABLE `grocery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `idqueue` int NOT NULL AUTO_INCREMENT,
  `idgrocery` int NOT NULL,
  PRIMARY KEY (`idqueue`),
  UNIQUE KEY `idgrocery_UNIQUE` (`idgrocery`),
  CONSTRAINT `f_01_queue` FOREIGN KEY (`idgrocery`) REFERENCES `grocery` (`idgrocery`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2442 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
INSERT INTO `queue` VALUES (1930,2234),(1931,2235),(1932,2236),(2188,2501),(2189,2502);
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation` (
  `idreservation` int NOT NULL AUTO_INCREMENT,
  `idcustomer` int NOT NULL,
  `idqueue` int NOT NULL,
  `type` varchar(10) NOT NULL,
  `QRcode` bigint DEFAULT NULL,
  `estimatedTime` datetime DEFAULT NULL,
  `status` varchar(10) NOT NULL,
  `lineUpNumber` int DEFAULT NULL,
  `timeEntrance` datetime DEFAULT NULL,
  `timeExit` datetime DEFAULT NULL,
  `bookTime` datetime DEFAULT NULL,
  PRIMARY KEY (`idreservation`),
  KEY `f_01_reservation_idx` (`idcustomer`),
  KEY `f_02_reservation_idx` (`idqueue`),
  CONSTRAINT `f_01_reservation` FOREIGN KEY (`idcustomer`) REFERENCES `user` (`iduser`) ON UPDATE CASCADE,
  CONSTRAINT `f_02_reservation` FOREIGN KEY (`idqueue`) REFERENCES `queue` (`idqueue`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2273 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` VALUES (1823,2426,1931,'LINEUP',NULL,'2021-02-07 10:17:10','OPEN',NULL,NULL,NULL,NULL),(1824,2426,1932,'LINEUP',NULL,'2021-02-07 11:27:40','CLOSED',NULL,NULL,NULL,NULL),(1986,2659,1932,'LINEUP',NULL,'2021-02-07 14:57:41','CLOSED',NULL,NULL,NULL,NULL),(1987,2661,1932,'LINEUP',NULL,'2021-02-07 15:52:47','CLOSED',NULL,NULL,NULL,NULL),(2035,2731,2189,'LINEUP',NULL,'2021-02-07 17:07:56','CLOSED',NULL,NULL,NULL,NULL),(2037,2733,2189,'LINEUP',NULL,'2021-02-07 17:22:47','CLOSED',NULL,NULL,NULL,NULL),(2038,2734,2189,'LINEUP',NULL,'2021-02-07 17:28:47','CLOSED',NULL,NULL,NULL,NULL),(2039,2735,2189,'LINEUP',NULL,'2021-02-07 17:50:33','CLOSED',NULL,NULL,NULL,NULL),(2040,2736,2189,'LINEUP',NULL,'2021-02-07 17:55:23','CLOSED',NULL,NULL,NULL,NULL),(2041,2737,2189,'LINEUP',NULL,'2021-02-07 18:10:21','CLOSED',NULL,NULL,NULL,NULL),(2042,2738,2189,'LINEUP',NULL,'2021-02-07 18:51:13','CLOSED',NULL,NULL,NULL,NULL),(2043,2739,2189,'LINEUP',NULL,'2021-02-07 18:26:52','CLOSED',NULL,NULL,NULL,NULL),(2044,2740,2189,'LINEUP',NULL,'2021-02-07 18:32:40','CLOSED',NULL,NULL,NULL,NULL),(2045,2741,2189,'LINEUP',NULL,'2021-02-07 18:38:49','CLOSED',NULL,NULL,NULL,NULL),(2078,2785,2189,'LINEUP',NULL,'2021-02-07 19:18:17','OPEN',NULL,NULL,NULL,NULL),(2081,2788,2189,'LINEUP',NULL,'2021-02-07 19:42:16','CLOSED',NULL,NULL,NULL,NULL),(2174,2921,2189,'LINEUP',NULL,'2021-02-07 20:02:38','CLOSED',NULL,NULL,NULL,NULL),(2176,2923,2189,'LINEUP',NULL,'2021-02-07 20:08:58','CLOSED',NULL,NULL,NULL,NULL),(2177,2924,2189,'LINEUP',NULL,'2021-02-07 20:09:16','ENTERED',NULL,NULL,NULL,NULL),(2178,2925,2189,'LINEUP',NULL,'2021-02-07 20:16:27','ENTERED',NULL,NULL,NULL,NULL),(2179,2926,2189,'LINEUP',NULL,'2021-02-07 20:18:45','OPEN',NULL,NULL,NULL,NULL),(2226,2994,2189,'LINEUP',NULL,'2021-02-07 20:41:19','ALLOWED',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `iduser` int NOT NULL AUTO_INCREMENT,
  `role` varchar(20) NOT NULL,
  `telephoneNumber` varchar(20) NOT NULL,
  `username` varchar(40) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`iduser`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3061 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2424,'MANAGER','11111111111','admin0','admin0','admin'),(2425,'VISITOR','0',NULL,NULL,NULL),(2426,'REG_CUSTOMER','22222222222','user0','user0','user0'),(2625,'REG_CUSTOMER','66666666666','user1','user1','user1'),(2659,'VISITOR','0',NULL,NULL,NULL),(2660,'VISITOR','0',NULL,NULL,NULL),(2661,'VISITOR','0',NULL,NULL,NULL),(2728,'VISITOR','22222222222',NULL,NULL,NULL),(2729,'VISITOR','3315990370',NULL,NULL,NULL),(2730,'VISITOR','888888888888',NULL,NULL,NULL),(2731,'VISITOR','22222222222',NULL,NULL,NULL),(2732,'VISITOR','66666666666',NULL,NULL,NULL),(2733,'VISITOR','22222222222',NULL,NULL,NULL),(2734,'VISITOR','66666666666',NULL,NULL,NULL),(2735,'VISITOR','66666666666',NULL,NULL,NULL),(2736,'VISITOR','22222222222',NULL,NULL,NULL),(2737,'VISITOR','22222222222',NULL,NULL,NULL),(2738,'VISITOR','66666666666',NULL,NULL,NULL),(2739,'VISITOR','22222222222',NULL,NULL,NULL),(2740,'VISITOR','66666666666',NULL,NULL,NULL),(2741,'VISITOR','3315990370',NULL,NULL,NULL),(2742,'VISITOR','11111111111',NULL,NULL,NULL),(2776,'VISITOR','66666666666',NULL,NULL,NULL),(2777,'VISITOR','22222222222',NULL,NULL,NULL),(2778,'VISITOR','66666666666',NULL,NULL,NULL),(2779,'VISITOR','22222222222',NULL,NULL,NULL),(2780,'VISITOR','22222222222',NULL,NULL,NULL),(2781,'VISITOR','22222222222',NULL,NULL,NULL),(2782,'VISITOR','66666666666',NULL,NULL,NULL),(2783,'VISITOR','3315990370',NULL,NULL,NULL),(2784,'VISITOR','22222222222',NULL,NULL,NULL),(2785,'VISITOR','66666666666',NULL,NULL,NULL),(2786,'VISITOR','22222222222',NULL,NULL,NULL),(2787,'VISITOR','11111111111',NULL,NULL,NULL),(2788,'VISITOR','22222222222',NULL,NULL,NULL),(2921,'VISITOR','22222222222',NULL,NULL,NULL),(2922,'VISITOR','22222222222',NULL,NULL,NULL),(2923,'VISITOR','66666666666',NULL,NULL,NULL),(2924,'VISITOR','22222222222',NULL,NULL,NULL),(2925,'VISITOR','22222222222',NULL,NULL,NULL),(2926,'VISITOR','66666666666',NULL,NULL,NULL),(2993,'EMPLOYEE','100000000000','emp0','emp0','emp0@email'),(2994,'VISITOR','22222222222',NULL,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'db_project_se2'
--

--
-- Dumping routines for database 'db_project_se2'
--
/*!50003 DROP FUNCTION IF EXISTS `getVisitMinutes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `getVisitMinutes`(startTime Datetime, endTime Datetime) RETURNS int
    DETERMINISTIC
BEGIN
RETURN  timestampdiff(MINUTE, startTime, endTime);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `favourite_groceries(idcustomer, numreservations)`
--

/*!50001 DROP VIEW IF EXISTS `favourite_groceries(idcustomer, numreservations)`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `favourite_groceries(idcustomer, numreservations)` AS select `reservation`.`idcustomer` AS `idcustomer`,count(0) AS `numReservations` from `reservation` group by `reservation`.`idqueue` order by `numReservations` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-07 22:07:47
